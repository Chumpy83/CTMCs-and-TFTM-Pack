// priority: 0

settings.logAddedRecipes = true
settings.logRemovedRecipes = true
settings.logSkippedRecipes = false
settings.logErroringRecipes = true

console.info('Hello, World! (You will see this line every time server resources reload)')


//swap all recipe instances of minecraft:wheat with any tfc grain
onEvent('recipes', event => {
	event.replaceInput(
		{ input: 'minecraft:wheat'},
		'minecraft:wheat',
		'#tfc:foods/grains'
		)
	}
)
//swap out the iron block for barracks for an armor stand
//onEvent('recipes', event => {
//	event.shaped(
//		Item.of('minecolonies:blockhutbarracks',1) [
//		  'XTX',
//		  'XBX',
//		  'XXX'
//		],
//		{
//			X: 'minecraft:planks', 
//			B: 'minecraft:armor_stand',
//			T: 'structurize:sceptergold'   
//		  		}
//			)
//		}
//	)
//swap all recipe instances of minecraft:beehive for firmalife:beehive
onEvent('recipes', event => {
	event.replaceInput(
		{ input: 'minecraft:beehive'},
		'minecraft:beehive',
		'firmalife:beehive'
		)
	}
)
//swap all recipe instances of minecraft:iron in MineColonies for forge:ingots
onEvent('recipes', event => {
	event.replaceInput(
		{ mod: 'minecolonies', input: 'minecraft:iron_ingot' },
		'minecraft:iron_ingot',
		'#forge:ingots'
		)
	}
)
//swap all recipe instances of minecraft:egg for tag forge:egg
onEvent('recipes', event => {
	event.replaceInput(
		{ input: 'minecraft:egg'},
		'minecraft:egg',
		'#forge:eggs'
		)
	}
)
//swap all recipe instances of minecraft:iron_sword for tag tfc:swords
onEvent('recipes', event => {
	event.replaceInput(
		{ input: 'minecraft:iron_sword'},
		'minecraft:iron_sword',
		'#forge:swords'
		)
	}
)
//swap all recipe instances of minecraft:dirt for tag minecraft:dirt
onEvent('recipes', event => {
	event.replaceInput(
		{ input: 'minecraft:dirt'},
		'minecraft:dirt',
		'#minecraft:dirt'
		)
	}
)
//swap all recipe instances of minecraft:cobble in MineColonies for forge:cobble
onEvent('recipes', event => {
	
	}
)
onEvent('recipes', event => {
	event.replaceInput(
		{ mod: 'minecolonies', input: 'minecraft:string' },
		'minecraft:string',
		'#forge:string'
	),
	event.replaceInput(
		{ mod: 'minecolonies', input: 'minecraft:beef' },
		'minecraft:beef',
		'tfc:food/beef'
	),
	event.replaceInput(
		{ mod: 'minecolonies', input: 'minecraft:cobblestone' },
		'minecraft:cobblestone',
		'#forge:cobblestone'
	),
	event.replaceInput(
		{ mod: 'structurize', input: 'minecraft:cobblestone' },
		'minecraft:cobblestone',
		'#forge:cobblestone'
	),
	event.replaceInput(
		{ mod: 'domum_ornamentum', input: 'minecraft:stone_slab' },
		'minecraft:stone_slab',
		'#minecraft:slabs'
	),
	event.replaceInput(
		{ mod: 'domum_ornamentum', input: 'minecraft:iron_ingot' },
		'minecraft:iron_ingot',
		'#forge:ingots'
	),
	event.replaceInput(
		{ mod: 'minecolonies', input: 'minecraft:poppy' },
		'minecraft:poppy',
		'#minecraft:flowers'
	),
	event.replaceInput(
		{ mod: 'minecolonies', input: 'minecraft:carrot' },
		'minecraft:carrot',
		'#tfc:foods/vegetables'
	),
	event.replaceInput(
		{ mod: 'minecolonies', input: 'minecraft:apple' },
		'minecraft:apple',
		'#tfc:foods/fruits'
	),
	event.replaceInput(
		{ mod: 'minecolonies', input: 'minecraft:diamond' },
		'minecraft:diamond',
		'#forge:gems'
	),
	event.replaceInput(
		{ mod: 'minecolonies', input: 'minecraft:porkchop' },
		'minecraft:porkchop',
		'tfc:food/pork'
	),
	event.replaceInput(
		{ mod: 'minecolonies', input: 'minecraft:rabbit' },
		'minecraft:rabbit',
		'tfc:food/rabbit'
	),
	event.replaceInput(
		{ mod: 'minecolonies', input: 'minecraft:iron_nugget' },
		'minecraft:iron_nugget',
		'#forge:nuggets'
	),
	event.replaceInput(
		{ mod: 'minecolonies', input: 'minecraft:cactus' },
		'minecraft:cactus',
		'tfc:seeds/jute'
	),
	event.replaceInput(
		{ mod: 'minecolonies', input: 'minecraft:stone' },
		'minecraft:stone',
		'#forge:stone'
	),		
	event.replaceInput(
		{ mod: 'minecolonies', input: 'minecraft:torch' },
		'minecraft:torch',
		'tfc:torch'
	),
	event.replaceInput(
		{ mod: 'minecolonies', input: 'minecraft:barrel' },
		'minecraft:barrel',
		'#tfc:barrels'
	),	
	event.replaceInput(
		{ mod: 'minecolonies', input: 'minecraft:stone_bricks' },
		'minecraft:stone_bricks',
		'#forge:stone_bricks'
	)
	}
)
onEvent('recipes', event => {
	event.remove({ id: 'minecolonies:blockhutfisherman'}),
	event.remove({ id: 'minecolonies:blockhutbarracks'}),
	event.remove({ id: 'minecolonies:blockhutcombatacademy'}),
	event.remove({ id: 'minecolonies:blockhutlumberjack'}),
	event.remove({ id: 'minecolonies:blockhutminer'}),
	event.remove({ id: 'minecolonies:blockhutfarmer'}),
	event.remove({ id: 'minecolonies:blockhutlumberjack'}),
	event.remove({ id: 'minecolonies:blockhutminer'}),
	event.remove({ id: 'minecolonies:blockhutfarmer'}),
	event.remove({ id: 'minecolonies:simplequarry'}),
	event.remove({ id: 'minecolonies:mediumquarry'}),
	event.remove({ id: 'minecolonies:blockhutsawmill'}),
	event.remove({ id: 'minecolonies:blockhutshepherd'}),
	event.remove({ id: 'minecolonies:blockhutenchanter'}),
	event.remove({ id: 'minecraft:brewing_stand'})//,
//	event.remove({ id: 'structurize:sceptergold'})
	
}
)
onEvent('recipes', event => {
	event.shaped(
		Item.of('minecolonies:blockhutfisherman',1),
		[  'XLX',
	       'XDX',
		   'XXX'],
		{ 
		  X: '#minecraft:planks',
	      L: 'structurize:sceptergold',
		  D: '#forge:fishing_rods'
		}
	),
	event.shaped(
		Item.of('minecolonies:blockhutbarracks',1),
		[  'XLX',
	       'XDX',
		   'XXX'],
		{ 
		  X: '#minecraft:planks',
	      L: 'structurize:sceptergold',
		  D: 'minecraft:armor_stand'
		}
	),
	event.shaped(
		Item.of('minecolonies:blockhutcombatacademy',1),
		[  'XLX',
	       'DDD',
		   'XXX'],
		{ 
		  X: '#minecraft:planks',
	      L: 'structurize:sceptergold',
		  D: '#forge:swords'
		}
	),
	event.shaped(
		Item.of('minecolonies:blockhutlumberjack',2),
		[  'XLX',
	       'XDX',
		   'XXX'],
		{ 
		  X: '#minecraft:planks',
	      L: 'structurize:sceptergold',
		  D: '#forge:axes'
		}
	),
	event.shaped(
		Item.of('minecolonies:blockhutminer',2),
		[  'XLX',
	       'XDX',
		   'XXX'],
		{ 
		  X: '#minecraft:planks',
	      L: 'structurize:sceptergold',
		  D: '#forge:pickaxes'
		}
	),	
	event.shaped(
		Item.of('minecolonies:simplequarry',2),
		[  'XLX',
	       'XDX',
		   'XBX'],
		{ 
		  X: '#minecraft:planks',
	      L: 'structurize:sceptergold',
		  D: '#forge:pickaxes',
		  B: '#tfc:barrels'
		}
	),
	event.shaped(
		Item.of('minecolonies:mediumquarry',1),
		[  'XLX',
	       'XDX',
		   'BXB'],
		{ 
		  X: '#minecraft:planks',
	      L: 'structurize:sceptergold',
		  D: '#forge:pickaxes',
		  B: '#tfc:barrels'
		}
	),
	event.shaped(
		Item.of('minecolonies:blockhutfarmer',2),
		[  'XLX',
	       'XDX',
		   'XXX'],
		{ 
		  X: '#minecraft:planks',
	      L: 'structurize:sceptergold',
		  D: '#forge:hoes'
		}
	),  
	event.shaped(
		Item.of('minecolonies:blockhutshepherd',1),
		[  'XLX',
	       'XDX',
		   'XXX'],
		{ 
		  X: '#minecraft:planks',
	      L: 'structurize:sceptergold',
		  D: '#forge:shears'
		}
	),
	event.shaped(
		Item.of('minecolonies:blockhutfarmer',2),
		[  'XLX',
	       'XDX',
		   'XXX'],
		{ 
		  X: '#minecraft:planks',
	      L: 'structurize:sceptergold',
		  D: '#forge:hoes'
		}
	),  
	event.shaped(
		Item.of('minecraft:brewing_stand',1),
		[  '   ',
	       ' R ',
		   ' P '],
		{ 
		  R: 'tfc:metal/rod/wrought_iron',
	      P: 'tfc:metal/sheet/wrought_iron',
		}
	),
	event.shaped(
		Item.of('structurize:sceptergold',1),
		[  '  D',
	       ' x ',
		   'X  '],
		{ 
			X: '#forge:rods/wooden',
			D: '#forge:cobblestone'
		}
	),
	event.shaped(
		Item.of('minecraft:campfire',1),
		[  ' S ',
	       'SGS',
		   'LLL'],
		{ 
			L: '#minecraft:logs',
			S: '#forge:rods/wooden',
			G: 'minecraft:charcoal'
		}
	),
	event.shaped(
		Item.of('tfc:firepit',1),
		[  ' S ',
	       'SGS',
		   'LLL'],
		{ 
			L: '#minecraft:logs',
			S: '#forge:rods/wooden',
			G: 'tfc:straw'
		}
	),
	event.shaped(
		Item.of('tfc:pot',1),
		[  '   ',
	       ' P ',
		   ' F '],
		{ 
			F: 'tfc:firepit',
			P: 'tfc:ceramic/pot',
		}
	),
	event.shaped(
		Item.of('minecolonies:blockhutsawmill',1),
		[  'XLX',
	       'XDX',
		   'XXX'],
		{ 
		  X: '#minecraft:planks',
	      L: 'structurize:sceptergold',
		  D: '#forge:saws'
		}
	)		
})
onEvent('item.tags', event => {
	// Get the #forge:cobblestone tag collection and add Diamond Ore to it
	// event.get('forge:cobblestone').add('minecraft:diamond_ore')

	// Get the #forge:cobblestone tag collection and remove Mossy Cobblestone from it
	// event.get('forge:cobblestone').remove('minecraft:mossy_cobblestone')
})